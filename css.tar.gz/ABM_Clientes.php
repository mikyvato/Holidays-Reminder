<?php

session_start();
include 'funciones_db.php';
/*
 * Archivo encargado de realizar Altas Bajas y Modificaciones 
 * de la entidad que lleva por nombre.
 */

$opcion = $_REQUEST['opcion'];

/**
 * Opcion es 1 se realiza el alta 
 * 
 */

if ($opcion == 1){
    $CliNombre = $_POST['CliNombre'];
    $CliMail = $_POST['CliMail'];
    $CliHabilitado = 1;
    $Usuarios_idUsuarios = $_SESSION['idUsuarios'];
    $provincia_idProvincias = $_POST['idProvincias'];
    $provincia_Pais_idPais = $_POST['idPais'];
    
    $ins = " INSERT INTO cliente ";
    $ins .= " (`CliNombre`, `CliMail`, `CliHabilitado`, `Usuarios_idUsuarios`, `provincia_idProvincias`, `provincia_Pais_idPais`) ";
    $ins .= " VALUE ";
    $ins .= " ('$CliNombre', '$CliMail', $CliHabilitado, $Usuarios_idUsuarios, $provincia_idProvincias, $provincia_Pais_idPais) ";
    
    sql_INS($ins);
    
    header("Location: clientes.php?atajo=1&resultado=2&mostrar=10");
}

if ($opcion == 2){
    
    $idClientes = $_POST['idClientes'];
    $CliNombre = $_POST['CliNombre'];
    $CliMail = $_POST['CliMail'];
    $provincia_idProvincias = $_POST['idProvincias'];
    $provincia_Pais_idPais = $_POST['idPais'];
    
    $upd = " UPDATE cliente SET ";
    $upd .= " CliNombre = '$CliNombre', ";
    $upd .= " CliMail = '$CliMail', ";
    $upd .= " provincia_idProvincias = $provincia_idProvincias, ";
    $upd .= " provincia_Pais_idPais = $provincia_Pais_idPais ";
    $upd .= " WHERE ";
    $upd .= " idClientes = $idClientes ";
    
    sql_INS($upd);
    
    header("Location: clientes.php?atajo=1&resultado=2&mostrar=10");
}

if ($opcion == 3){
    
    $idClientes = $_GET['idClientes'];
    $estado = $_GET['estado'];
    
    $upd = " UPDATE cliente SET ";
    $upd .= " CliHabilitado = $estado ";
    $upd .= " WHERE ";
    $upd .= " idClientes = $idClientes ";
    
    sql_INS($upd);
    
    header("Location: clientes.php?atajo=1&resultado=4&mostrar=2$estado");
    
}
?>
