<?php
// Constantes de conexion a la base de datos
define ("DB_SERVIDOR", "localhost");
define ("DB_USUARIO", "root");
define ("DB_PASSWORD", "1234");
define ("DB_BASEDEDATOS", "Holidays");


?>